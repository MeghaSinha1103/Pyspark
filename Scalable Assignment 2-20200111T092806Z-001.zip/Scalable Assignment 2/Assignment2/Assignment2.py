# Data processing

# -----------------------------------------------
# Question 1(a) -> Structure Of each Directory 
# -----------------------------------------------

```
# audio/
    # attributes/
        # msd-jmir-area-of-moments-all-v1.0.attributes.csv
        # msd-jmir-lpc-all-v1.0.attributes.csv
        # msd-jmir-methods-of-moments-all-v1.0.attributes.csv
		# msd-jmir-mfcc-all-v1.0.attributes.csv
		# msd-jmir-spectral-all-all-v1.0.attributes.csv
		# msd-jmir-spectral-derivatives-all-all-v1.0.attributes.csv
		# msd-marsyas-timbral-v1.0.attributes.csv
		# msd-mvd-v1.0.attributes.csv
		# msd-rh-v1.0.attributes.csv
		# msd-rp-v1.0.attributes.csv
		# msd-ssd-v1.0.attributes.csv
		# msd-trh-v1.0.attributes.csv
		# msd-tssd-v1.0.attributes.csv

    # features/
        # msd-jmir-area-of-moments-all-v1.0.csv/
        # msd-jmir-lpc-all-v1.0.csv/
        # msd-jmir-methods-of-moments-all-v1.0.csv/
		# msd-jmir-mfcc-all-v1.0.csv/
		# msd-jmir-spectral-all-all-v1.0.csv/
		# msd-jmir-spectral-derivatives-all-all-v1.0.csv/
		# msd-marsyas-timbral-v1.0.csv/
		# msd-mvd-v1.0.csv/
		# msd-rh-v1.0.csv/
		# msd-rp-v1.0.csv/
		# msd-ssd-v1.0.csv/
		# msd-trh-v1.0.csv/
		# msd-tssd-v1.0.csv/
        
    # statistics/
        # sample_properties.csv.gz
# genre/
		# msd-MAGD-genreAssignment.tsv
		# msd-MASD-styleAssignment.tsv
		# msd-topMAGD-genreAssignment.tsv
# main/
	# summary/
		# analysis.csv.gz
		# metadata.csv.gz
# tasteprofile/
	# mismatches/
		# sid_matches_manually_accepted.txt
		# sid_mismatches.txt
	# triplets.tsv/
		# part-00000.tsv.gz
		# part-00001.tsv.gz
		# part-00002.tsv.gz
		# part-00003.tsv.gz
		# part-00004.tsv.gz
		# part-00005.tsv.gz
		# part-00006.tsv.gz
		# part-00007.tsv.gz


# ------------------------
# Size Of Each File
# ------------------------

# +---------------+---------+
# | audio/        | 12.3 GB |
# | genre/        | 30.1 MB |
# | main/         |174.4 MB |
# | tasteprofile/ |490.4 MB |
# +---------------+---------+


# ----------------------------
# Question 1(c)
# --------------------------

from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import *

from pretty import SparkPretty  # download pretty.py from LEARN and put in the same directory

spark = SparkSession.builder.getOrCreate()
sc = SparkContext.getOrCreate()
pretty = SparkPretty(limit=5)


# Load datasets

genre_schema = StructType([
    StructField("track_id", StringType(), True),
    StructField("genre", StringType(), True)
])
genres_magd = (
    spark.read.format("csv")
    .option("header", "false")
    .option("delimiter", "\t")
    .schema(genre_schema)
    .load("hdfs:///data/msd/genre/msd-MAGD-genreAssignment.tsv")
    .cache()
)
# genres_magd.count()

# -> 422714

genre_schema = StructType([
    StructField("track_id", StringType(), True),
    StructField("genre", StringType(), True)
])
genres_masd = (
    spark.read.format("csv")
    .option("header", "false")
    .option("delimiter", "\t")
    .schema(genre_schema)
    .load("hdfs:///data/msd/genre/msd-MASD-styleAssignment.tsv")
    .cache()
)
# genres_masd.count()

# -> 273936

genre_schema = StructType([
    StructField("track_id", StringType(), True),
    StructField("genre", StringType(), True)
])
genres_topmasd = (
    spark.read.format("csv")
    .option("header", "false")
    .option("delimiter", "\t")
    .schema(genre_schema)
    .load("hdfs:///data/msd/genre/msd-topMAGD-genreAssignment.tsv")
    .cache()
)
# genres_topmasd.count()

# -> 406427

# The Below command is used for viewing Line Count of all the files.

# hdfs dfs -cat hdfs:///data/msd/genre/msd-topMAGD-genreAssignment.tsv | wc -l

for i in `hdfs dfs -ls /data/msd/audio/attributes | awk '{print $8}'` ; do  echo $i ; hdfs dfs -cat $i | wc -l; done
 for i in `hdfs dfs -ls /data/msd/audio/features | awk '{print $8}'` ; do  echo $i ; hdfs dfs -cat $i/* | gunzip | wc -l; done
 hdfs dfs -cat /data/msd/audio/statistics/* | gunzip |wc -l
 for i in `hdfs dfs -ls /data/msd/genre | awk '{print $8}'` ; do  echo $i ; hdfs dfs -cat $i | wc -l; done
 for i in `hdfs dfs -ls /data/msd/main/summary | awk '{print $8}'` ; do  echo $i ; hdfs dfs -cat $i | gunzip | wc -l; done
 for i in `hdfs dfs -ls /data/msd/tasteprofile/mismatches | awk '{print $8}'` ; do  echo $i ; hdfs dfs -cat $i | wc -l; done
 hdfs dfs -cat /data/msd/tasteprofile/triplets.tsv/* | gunzip |wc -l

# /data/msd/audio/features/msd-jmir-area-of-moments-all-v1.0.csv
# 994623
# /data/msd/audio/features/msd-jmir-lpc-all-v1.0.csv
# 994623
# /data/msd/audio/features/msd-jmir-methods-of-moments-all-v1.0.csv
# 994623
# /data/msd/audio/features/msd-jmir-mfcc-all-v1.0.csv
# 994623
# /data/msd/audio/features/msd-jmir-spectral-all-all-v1.0.csv
# 994623
# /data/msd/audio/features/msd-jmir-spectral-derivatives-all-all-v1.0.csv
# 994623
# /data/msd/audio/features/msd-marsyas-timbral-v1.0.csv
# 995001
# /data/msd/audio/features/msd-mvd-v1.0.csv
# 994188
# /data/msd/audio/features/msd-rh-v1.0.csv
# 994188
# /data/msd/audio/features/msd-rp-v1.0.csv
# 994188
# /data/msd/audio/features/msd-ssd-v1.0.csv
# 994188
# /data/msd/audio/features/msd-trh-v1.0.csv
# 994188
# /data/msd/audio/features/msd-tssd-v1.0.csv
# 994188

# /data/msd/audio/attributes/msd-jmir-area-of-moments-all-v1.0.attributes.csv
# 21
# /data/msd/audio/attributes/msd-jmir-lpc-all-v1.0.attributes.csv
# 21
# /data/msd/audio/attributes/msd-jmir-methods-of-moments-all-v1.0.attributes.csv
# 11
# /data/msd/audio/attributes/msd-jmir-mfcc-all-v1.0.attributes.csv
# 27
# /data/msd/audio/attributes/msd-jmir-spectral-all-all-v1.0.attributes.csv
# 17
# /data/msd/audio/attributes/msd-jmir-spectral-derivatives-all-all-v1.0.attributes.csv
# 17
# /data/msd/audio/attributes/msd-marsyas-timbral-v1.0.attributes.csv
# 125
# /data/msd/audio/attributes/msd-mvd-v1.0.attributes.csv
# 421
# /data/msd/audio/attributes/msd-rh-v1.0.attributes.csv
# 61
# /data/msd/audio/attributes/msd-rp-v1.0.attributes.csv
# 1441
# /data/msd/audio/attributes/msd-ssd-v1.0.attributes.csv
# 169
# /data/msd/audio/attributes/msd-trh-v1.0.attributes.csv
# 421
# /data/msd/audio/attributes/msd-tssd-v1.0.attributes.csv
# 1177

# /data/msd/genre/msd-MAGD-genreAssignment.tsv
# 422714
# /data/msd/genre/msd-MASD-styleAssignment.tsv
# 273936
# /data/msd/genre/msd-topMAGD-genreAssignment.tsv
# 406427

# /data/msd/main/summary/analysis.csv.gz
# 1000001
# /data/msd/main/summary/metadata.csv.gz
# 1000001

# /data/msd/tasteprofile/mismatches/sid_matches_manually_accepted.txt
# 938
# /data/msd/tasteprofile/mismatches/sid_mismatches.txt
# 19094

# hdfs dfs -cat /data/msd/tasteprofile/triplets.tsv/* | gunzip |wc -l
# 48373586



# Python and pyspark modules required

import sys

from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

# Required to allow the file to be submitted and run using spark-submit instead
# of using pyspark interactively

spark = SparkSession.builder.getOrCreate()
sc = SparkContext.getOrCreate()



# ----------------------------
# Question 2(a)
# ----------------------------


mismatches_schema = StructType([
    StructField("song_id", StringType(), True),
    StructField("song_artist", StringType(), True),
    StructField("song_title", StringType(), True),
    StructField("track_id", StringType(), True),
    StructField("track_artist", StringType(), True),
    StructField("track_title", StringType(), True)
])

# mismatches

with open("/scratch-network/courses/2019/DATA420-19S2/data/msd/tasteprofile/mismatches/sid_mismatches.txt", "r") as f:
    lines = f.readlines()
    sid_mismatches = []
    for line in lines:
        if line.startswith("ERROR: "):
            a = line[8:26]
            b = line[27:45]
            c, d = line[47:-1].split("  !=  ")
            e, f = c.split("  -  ")
            g, h = d.split("  -  ")
            sid_mismatches.append((a, e, f, b, g, h))

mismatches = spark.createDataFrame(sc.parallelize(sid_mismatches, 64), schema=mismatches_schema)
# mismatches.cache()
# mismatches.show(10, 40)

print(mismatches.count())

# matches_manually_accepted

mismatches_schema = StructType([
    StructField("song_id", StringType(), True),
    StructField("song_artist", StringType(), True),
    StructField("song_title", StringType(), True),
    StructField("track_id", StringType(), True),
    StructField("track_artist", StringType(), True),
    StructField("track_title", StringType(), True)
])

with open("/scratch-network/courses/2019/DATA420-19S2/data/msd/tasteprofile/mismatches/sid_matches_manually_accepted.txt", "r") as f:
    lines = f.readlines()
    sid_mismatches_manually = []
    for line in lines:
	    #print(line)
        if line.startswith("< ERROR:"):
            a = line[10:28]
            b = line[29:47]
            c, d = line[49:-1].split("  !=  ")
            e, f = c.split("  -  ")
            g, h = d.split("  -  ")
            sid_mismatches_manually.append((a, e, f, b, g, h))

mismatches_manually = spark.createDataFrame(sc.parallelize(sid_mismatches_manually, 64), schema=mismatches_schema)
# mismatches_manually.cache()
# mismatches_manually.show(10, 40)

#print(mismatches_manually.count())

# matches_manually_accepted = spark.createDataFrame(sc.parallelize(sid_matches_manually_accepted, 8), schema=mismatches_schema)
# matches_manually_accepted.cache()
# matches_manually_accepted.show(10, 40)

# triplets

triplets_schema = StructType([
    StructField("user_id", StringType(), True),
    StructField("song_id", StringType(), True),
    StructField("plays", IntegerType(), True)
])
triplets = (
    spark.read.format("csv")
    .option("header", "false")
    .option("delimiter", "\t")
    .option("codec", "gzip")
    .schema(triplets_schema)
    .load("hdfs:///data/msd/tasteprofile/triplets.tsv/")
    .cache()
)
# triplets.cache()
# triplets.show(10, 50)

mismatches_not_accepted = mismatches.join(mismatches_manually, on="song_id", how="left_anti")
triplets_not_mismatched = triplets.join(mismatches_not_accepted, on="song_id", how="left_anti")

#print(triplets.count())
#print(triplets_not_mismatched.count())

## Output -> 

    # 48373586
    # 45795111

# ----------------------
# Question 2(b)
# -----------------------

## Automating the process of schema creation for the audio dataset.

from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import *
import re

from pretty import SparkPretty  # download pretty.py from LEARN and put in the same directory

spark = SparkSession.builder.getOrCreate()
sc = SparkContext.getOrCreate()
pretty = SparkPretty(limit=5)

audio_attribute_type_mapping = {
  "NUMERIC": DoubleType(),
  "real": DoubleType(),
  "string": StringType(),
  "STRING": StringType()
}


## This loads all the feature dataset as we have put all the features in the list ##

list = [
	"msd-jmir-area-of-moments-all-v1.0",
	"msd-jmir-lpc-all-v1.0",
	"msd-jmir-methods-of-moments-all-v1.0",
	"msd-jmir-mfcc-all-v1.0",
	"msd-jmir-spectral-all-all-v1.0",
	"msd-jmir-spectral-derivatives-all-all-v1.0",
	"msd-marsyas-timbral-v1.0",
	"msd-mvd-v1.0",
	"msd-rh-v1.0",
	"msd-rp-v1.0",
	"msd-ssd-v1.0",
	"msd-trh-v1.0",
	"msd-tssd-v1.0"
]

def load_attributes_file_and_convert_to_schema(attributes_path, type_mapping=audio_attribute_type_mapping):
    f = open(attributes_path, "r")
    rows = [line.strip().split(",") for line in f.readlines()]
    return StructType([StructField(row[0], audio_attribute_type_mapping[row[1]], True) for row in rows])

def load_dataset(dataset_name):
    attributes_path = f"/scratch-network/courses/2019/DATA420-19S2/data/msd/audio/attributes/{dataset_name}.attributes.csv"
    data_file_path = f"hdfs:///data/msd/audio/features/{dataset_name}.csv/*"
    dataset_schema = load_attributes_file_and_convert_to_schema(attributes_path)
    df = (
        spark.read
        .format("csv")
        .option("header", "false")
        .schema(dataset_schema)
        .load(data_file_path)
    )
    return df

# datasets = {dataset_name : load_dataset(dataset_name) for dataset_name in dataset_names}

for key in list:
    new_dataset = key
    new_dataset = datasets.get(key)
	new_dataset = load_dataset(key)
	new_dataset.show(10)


#####################################################
## Giving length of the column and count of rows for each dataset

for key in list:
    new_dataset = key
    new_dataset = datasets.get(key)
    new_dataset = load_dataset(key)
    print(new_dataset.count())
    print(len(new_dataset.columns))

# 994623
# 21
# 994623
# 21
# 994623
# 11
# 994623
# 27
# 994623
# 17
# 994623
# 17
# 995001
# 125
# 994188
# 421
# 994188
# 61
# 994188
# 1441
# 994188
# 169
# 994188
# 421
# 994188
# 1177

## In the above results obtained we see that the third column is small compared to rest hence will take this column for further question

########################################################## AUDIO ##########################

## Loading the genre dataset.

# ----------------------
# Question 1(a)
# ------------------------


## dataset names - This loads a particular feature dataset that is msd-jmir-methods-of-moments-all-v1.0 ##

dataset_names = [
	"msd-jmir-methods-of-moments-all-v1.0"
	
]

for key in dataset_names:
    new_dataset = key
    new_dataset = datasets.get(key)
	new_dataset = load_dataset(key)
	columns = new_dataset.schema.names
	print(columns)
	for values in columns:
		new_dataset.describe(values).show()
# +-------+----------------------------------------------+
# |summary|Method_of_Moments_Overall_Standard_Deviation_1|
# +-------+----------------------------------------------+
# |  count|                                        994623|
# |   mean|                            0.1549817600174655|
# | stddev|                           0.06646213086143041|
# |    min|                                           0.0|
# |    max|                                         0.959|
# +-------+----------------------------------------------+

# +-------+----------------------------------------------+
# |summary|Method_of_Moments_Overall_Standard_Deviation_2|
# +-------+----------------------------------------------+
# |  count|                                        994623|
# |   mean|                            10.384550576951835|
# | stddev|                            3.8680013938747018|
# |    min|                                           0.0|
# |    max|                                         55.42|
# +-------+----------------------------------------------+

# +-------+----------------------------------------------+
# |summary|Method_of_Moments_Overall_Standard_Deviation_3|
# +-------+----------------------------------------------+
# |  count|                                        994623|
# |   mean|                             526.8139724398112|
# | stddev|                             180.4377549977511|
# |    min|                                           0.0|
# |    max|                                        2919.0|
# +-------+----------------------------------------------+

# +-------+----------------------------------------------+
# |summary|Method_of_Moments_Overall_Standard_Deviation_4|
# +-------+----------------------------------------------+
# |  count|                                        994623|
# |   mean|                             35071.97543290272|
# | stddev|                            12806.816272955532|
# |    min|                                           0.0|
# |    max|                                      407100.0|
# +-------+----------------------------------------------+

# +-------+----------------------------------------------+
# |summary|Method_of_Moments_Overall_Standard_Deviation_5|
# +-------+----------------------------------------------+
# |  count|                                        994623|
# |   mean|                             5297870.369577217|
# | stddev|                            2089356.4364557962|
# |    min|                                           0.0|
# |    max|                                       4.657E7|
# +-------+----------------------------------------------+

# +-------+-----------------------------------+
# |summary|Method_of_Moments_Overall_Average_1|
# +-------+-----------------------------------+
# |  count|                             994623|
# |   mean|                 0.3508444432531261|
# | stddev|                 0.1855795683438387|
# |    min|                                0.0|
# |    max|                              2.647|
# +-------+-----------------------------------+

# +-------+-----------------------------------+
# |summary|Method_of_Moments_Overall_Average_2|
# +-------+-----------------------------------+
# |  count|                             994623|
# |   mean|                  27.46386798784021|
# | stddev|                  8.352648595163698|
# |    min|                                0.0|
# |    max|                              117.0|
# +-------+-----------------------------------+

# +-------+-----------------------------------+
# |summary|Method_of_Moments_Overall_Average_3|
# +-------+-----------------------------------+
# |  count|                             994623|
# |   mean|                 1495.8091812075486|
# | stddev|                 505.89376391902437|
# |    min|                                0.0|
# |    max|                             5834.0|
# +-------+-----------------------------------+

# +-------+-----------------------------------+
# |summary|Method_of_Moments_Overall_Average_4|
# +-------+-----------------------------------+
# |  count|                             994623|
# |   mean|                 143165.46163257837|
# | stddev|                 50494.276171032136|
# |    min|                          -146300.0|
# |    max|                           452500.0|
# +-------+-----------------------------------+

# +-------+-----------------------------------+
# |summary|Method_of_Moments_Overall_Average_5|
# +-------+-----------------------------------+
# |  count|                             994623|
# |   mean|                2.396783048473542E7|
# | stddev|                  9307340.299219608|
# |    min|                                0.0|
# |    max|                            9.477E7|
# +-------+-----------------------------------+

# +-------+--------------------+
# |summary|         MSD_TRACKID|
# +-------+--------------------+
# |  count|              994623|
# |   mean|                null|
# | stddev|                null|
# |    min|'TRAAAAK128F9318786'|
# |    max|'TRZZZZO128F428E2D4'|
# +-------+--------------------+


## Finding correlation between the columns

   
from pyspark.mllib.stat import Statistics
import pandas as pd

# df = sqlCtx.read.format('com.databricks.spark.csv').option('header', 'true').option('inferschema', 'true').load('corr_test.csv')
df = new_dataset.select(F.col("Method_of_Moments_Overall_Standard_Deviation_1").alias("MOM_SD_1"), F.col("Method_of_Moments_Overall_Standard_Deviation_2").alias("MOM_SD_2"),F.col("Method_of_Moments_Overall_Standard_Deviation_3").alias("MOM_SD_3"),F.col("Method_of_Moments_Overall_Standard_Deviation_4").alias("MOM_SD_4"),F.col("Method_of_Moments_Overall_Standard_Deviation_5").alias("MOM_SD_5"),F.col("Method_of_Moments_Overall_Average_1").alias("MOM_AVG_1"),F.col("Method_of_Moments_Overall_Average_2").alias("MOM_AVG_2"),F.col("Method_of_Moments_Overall_Average_3").alias("MOM_AVG_3"),F.col("Method_of_Moments_Overall_Average_4").alias("MOM_AVG_4"),F.col("Method_of_Moments_Overall_Average_5").alias("MOM_AVG_5"))
col_names = df.columns
features = df.rdd.map(lambda row: row[:])
corr_mat=Statistics.corr(features, method="pearson")
corr_df = pd.DataFrame(corr_mat)
corr_df.index, corr_df.columns = col_names[:], col_names[:]
print(corr_df.to_string())


           # MOM_SD_1  MOM_SD_2  MOM_SD_3  MOM_SD_4  MOM_SD_5  MOM_AVG_1  MOM_AVG_2  MOM_AVG_3  MOM_AVG_4  MOM_AVG_5
# MOM_SD_1   1.000000  0.426280  0.296306  0.061039 -0.055336   0.754208   0.497929   0.447565   0.167466   0.100407
# MOM_SD_2   0.426280  1.000000  0.857549  0.609521  0.433797   0.025228   0.406923   0.396354   0.015607  -0.040902
# MOM_SD_3   0.296306  0.857549  1.000000  0.803010  0.682909  -0.082415   0.125910   0.184962  -0.088174  -0.135056
# MOM_SD_4   0.061039  0.609521  0.803010  1.000000  0.942244  -0.327691  -0.223220  -0.158231  -0.245034  -0.220873
# MOM_SD_5  -0.055336  0.433797  0.682909  0.942244  1.000000  -0.392551  -0.355019  -0.285966  -0.260198  -0.211813
# MOM_AVG_1  0.754208  0.025228 -0.082415 -0.327691 -0.392551   1.000000   0.549015   0.518503   0.347112   0.278513
# MOM_AVG_2  0.497929  0.406923  0.125910 -0.223220 -0.355019   0.549015   1.000000   0.903367   0.516499   0.422549
# MOM_AVG_3  0.447565  0.396354  0.184962 -0.158231 -0.285966   0.518503   0.903367   1.000000   0.772807   0.685645
# MOM_AVG_4  0.167466  0.015607 -0.088174 -0.245034 -0.260198   0.347112   0.516499   0.772807   1.000000   0.984867
# MOM_AVG_5  0.100407 -0.040902 -0.135056 -0.220873 -0.211813   0.278513   0.422549   0.685645   0.984867   1.000000


############### Correlation Plot ###########

import seaborn as sns
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(10, 10))
mask = np.zeros_like(corr_df, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True
cmap = sns.diverging_palette(220, 10, as_cmap=True)
plot = sns.heatmap(corr_df,mask = mask, cmap = cmap ,vmax=1, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot = True, ax = ax)
plt.savefig("heatmap.pdf")

##############################################################



# -------------------
# Question 1(b)
# ------------------------


genre_schema = StructType([
    StructField("track_id", StringType(), True),
    StructField("genre", StringType(), True)
])
genres_magd = (
    spark.read.format("csv")
    .option("header", "false")
    .option("delimiter", "\t")
    .schema(genre_schema)
    .load("hdfs:///data/msd/genre/msd-MAGD-genreAssignment.tsv")
    .cache()
)
genres_magd.show(10)

## Taking the genre for only the matched dataset
mismatches_not_accepted = mismatches.join(mismatches_manually, on="song_id", how="left_anti")
genres_magd_not_mismatched = genres_magd.join(mismatches_not_accepted, on="track_id", how="left_anti")

### Distribution of the magd 


hist = genres_magd_not_mismatched.groupby(
  'genre'
).count()

hist.write.csv("hdfs:///user/mss152/outputs/hist.csv")


## Question1(c) -> Merge the genres dataset and the audio features dataset so that every song has a label

datasets = {dataset_name : load_dataset(dataset_name) for dataset_name in dataset_names}

for key in dataset_names:
    new_dataset = key
    new_dataset = datasets.get(key)
    feature_chosen = load_dataset(key)

# feature_chosen.printSchema()
 # MSD_TRACKID --> this is for the feature_chosen dataset 
 # track_id --> for genres_magd
 

## Cleaning the Feature_chosen dataset ##

#genres_magd.filter(F.col("track_id") == "TRHFHQZ12903C9E2D5").show()
feature_chosen_cleaned = (feature_chosen.withColumn('MSD_TRACKID_cleaned',F.trim(F.substring(F.col('MSD_TRACKID'),2,18))))
# feature_chosen_cleaned = feature_chosen_cleaned.drop("MSD_TRACKID")
# feature_chosen_cleaned.show()


## Merging the tables genre and features ##

Joined_Table = feature_chosen_cleaned.join(genres_magd_not_mismatched,feature_chosen_cleaned.MSD_TRACKID_cleaned == genres_magd_not_mismatched.track_id, how = "inner")
Joined_Table = Joined_Table.drop("MSD_TRACKID_cleaned")


## Question 2(a) 

# Chosen logistic Regression, Random Forest and Gradient Boost


## Question 2(b)

# Joined_Table:
# In [51]: Joined_Table.printSchema()
# root
 # |-- Method_of_Moments_Overall_Standard_Deviation_1: double (nullable = true)
 # |-- Method_of_Moments_Overall_Standard_Deviation_2: double (nullable = true)
 # |-- Method_of_Moments_Overall_Standard_Deviation_3: double (nullable = true)
 # |-- Method_of_Moments_Overall_Standard_Deviation_4: double (nullable = true)
 # |-- Method_of_Moments_Overall_Standard_Deviation_5: double (nullable = true)
 # |-- Method_of_Moments_Overall_Average_1: double (nullable = true)
 # |-- Method_of_Moments_Overall_Average_2: double (nullable = true)
 # |-- Method_of_Moments_Overall_Average_3: double (nullable = true)
 # |-- Method_of_Moments_Overall_Average_4: double (nullable = true)
 # |-- Method_of_Moments_Overall_Average_5: double (nullable = true)
 # |-- MSD_TRACKID: string (nullable = true)
 # |-- MSD_TRACKID_cleaned: string (nullable = true)
 # |-- track_id: string (nullable = true)
 # |-- genre: string (nullable = true)


## Adding extra column Electronics to the joined table ##

Joined_Table_new = (Joined_Table.withColumn('Electronic',F.when(Joined_Table.genre.isin("Electronic"),1).otherwise(0)))

#Joined_Table_new.show(10)


# In [60]: Joined_Table_new.filter(F.col("Electronic") == 1).count()
# Out[60]: 40027
# In [61]: Joined_Table_new.filter(F.col("Electronic") == 0).count()
# Out[61]: 373266

######################## Plotting distribution of various features to see if standardization of the vectors are required ###############


# summary = (dataset.describe().filter(F.col("summary") == "mean"))
# summary.write.csv("hdfs:///user/mss152/outputs/summary.csv")

################################### Creating pipeline for the models (Pre-processing the Data)#############################

from pyspark.ml import Pipeline
from pyspark.ml.feature import VectorAssembler
## from pyspark.ml.feature import StandardScaler  --> Not required
from pyspark.ml.feature import PCA
from pyspark.ml.linalg import Vectors

data = Joined_Table_new.withColumnRenamed("Electronic", "label")

## Dropping the Unique Identifiers

data = (data.na.drop().drop("track_id","MSD_TRACKID"))


## removing highly correlated column ##
data = (data.drop("Method_of_Moments_Overall_Average_5"))


col = data.drop("genre","label").columns
amt_assembler = VectorAssembler(inputCols = col,outputCol ="features")
## standardscaler=StandardScaler().setInputCol("features").setOutputCol("Scaled_features")
pca = PCA(k=3, inputCol="features", outputCol="pcaFeatures")

pipeline = Pipeline(stages=[amt_assembler])
pipelineFit = pipeline.fit(data)
dataset = pipelineFit.transform(data)
#dataset.show(5)


pcaFit = pca.fit(dataset)
dataset = pcaFit.transform(dataset) # --> PCA Features Not giving much difference.

############################## Splitting the dataset - Stratified sampling ############################

## Splitting the Dataset Using SamplyBy Method which does not give Exact stratified sampling.

thisdict =	{
  0: 0.7,
  1: 0.7
  }

train = dataset.stat.sampleBy("label",fractions = thisdict,seed = 100)
test = dataset.subtract(train)


## Splitting The Dataset Using Exact Stratified Sampling as below

from pyspark.sql.window import *

temp = (
    dataset
    .withColumn("id", monotonically_increasing_id())
    .withColumn("Random", rand())
    .withColumn(
        "Row",
        row_number()
        .over(
            Window
            .partitionBy("label")
            .orderBy("Random")
        )
    )
)
train = temp.where(
    ((F.col("label") == 0) & (F.col("Row") < 373266 * 0.8)) |
    ((F.col("label") == 1) & (F.col("Row") < 40027 * 0.8))
)
train.cache()

test = temp.join(train, on="id", how="left_anti")
test.cache()

train = train.drop("id", "Random", "Row")
test = test.drop("id", "Random", "Row")

def print_class_balance(data, name):
    N = data.count()
    counts = data.groupBy("label").count().toPandas()
    counts["ratio"] = counts["label"] / N
    print(name)
    print(N)
    print(counts)
    print("")


print_class_balance(dataset, "Dataset")
print_class_balance(train, "training")
print_class_balance(test, "test")

############################################### Logistic regression ###############################


from pyspark.ml.classification import LogisticRegression


lr = LogisticRegression(labelCol="label", featuresCol="features", maxIter=10, threshold = 0.3)

lrModel = lr.fit(train)
predictions = lrModel.transform(test)
selected = predictions.select("label", "prediction", "probability")

from pyspark.ml.evaluation import BinaryClassificationEvaluator
evaluator = BinaryClassificationEvaluator()

evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"}) # ROC = 0.7319143624104766

# Precision = 0.10941793654758931
# Recall = 0.41379310344827586
# F1 Score = 0.1730712239454707
# Out[38]:
# array([[73413.,  7130.],
       # [ 1241.,   876.]])



########################################### class weight ##################################################

train1 = (train.filter(F.col("label") == 1).count())
train0 = (train.filter(F.col("label") == 0).count())
train_count = train.count()

BalancingRatio= train0/train_count
print('BalancingRatio = {}'.format(BalancingRatio))

train=train.withColumn("classWeights", F.when(train.label == 1,BalancingRatio).otherwise(1-BalancingRatio))
train.select("classWeights").show(5)

lr = LogisticRegression(labelCol="label", featuresCol="features",weightCol="classWeights",maxIter=10, threshold = 0.3)

lrModel = lr.fit(train)
predictions = lrModel.transform(test)
selected = predictions.select("label", "prediction", "probability")

from pyspark.ml.evaluation import BinaryClassificationEvaluator
evaluator = BinaryClassificationEvaluator()

evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"})

#### With threshold 0.3 ########

# ROC = 0.746827541926941
# Summary Stats
# Precision = 0.9143142643017736
# Recall = 0.12219347299891495
# F1 Score = 0.2155762689402306
# Out[47]:
# array([[22069.,   686.],
       # [52585.,  7320.]])
 
########### Changing threshold to 0.5 #####

# ROC = 0.7468275419269411
# Summary Stats
# Precision = 0.6947289532850363
# Recall = 0.19096995708154507
# F1 Score = 0.29958794538256445
# Out[49]:
# array([[51091.,  2444.],
       # [23563.,  5562.]])

       
############################# Using RDD for the Calculation of Metrics for Logistic regression #################################################

from pyspark.mllib.evaluation import MulticlassMetrics



def getrdd(predictions):
    predictions = (predictions.select("label","prediction").withColumn("label", predictions["label"].cast(DoubleType())).rdd
                   )
         
      
    return predictions
 
predictionAndLabels = getrdd(predictions)

# Compute raw scores on the test set
# predictionAndLabels = testrdd.map(lambda lp: (float(lrModel.predict(lp.features)), lp.label))

# Instantiate metrics object
metrics = MulticlassMetrics(predictionAndLabels)

# Overall statistics
precision = metrics.precision(1)
recall = metrics.recall(1)
f1Score = metrics.fMeasure(1.0)
print("Summary Stats")
print("Precision = %s" % precision)
print("Recall = %s" % recall)
print("F1 Score = %s" % f1Score)
MulticlassMetrics(predictionAndLabels).confusionMatrix().toArray()


####################### Using Custom parameter for printing Binary metrics For Logistic regression (DID NOT IMPLEMENT YET)##########

def print_binary_metrics(predictions, labelCol="Class", predictionCol="prediction", rawPredictionCol="rawPrediction"):

    total = predictions.count()
    positive = predictions.filter((col(labelCol) == 1)).count()
    negative = predictions.filter((col(labelCol) == 0)).count()
    nP = predictions.filter((col(predictionCol) == 1)).count()
    nN = predictions.filter((col(predictionCol) == 0)).count()
    TP = predictions.filter((col(predictionCol) == 1) & (col(labelCol) == 1)).count()
    FP = predictions.filter((col(predictionCol) == 1) & (col(labelCol) == 0)).count()
    FN = predictions.filter((col(predictionCol) == 0) & (col(labelCol) == 1)).count()
    TN = predictions.filter((col(predictionCol) == 0) & (col(labelCol) == 0)).count()

    binary_evaluator = BinaryClassificationEvaluator(rawPredictionCol="rawPrediction", labelCol=labelCol, metricName="areaUnderROC")
    auroc = binary_evaluator.evaluate(predictions)

    print('actual total:    {}'.format(total))
    print('actual positive: {}'.format(positive))
    print('actual negative: {}'.format(negative))
    print('nP:              {}'.format(nP))
    print('nN:              {}'.format(nN))
    print('TP:              {}'.format(TP))
    print('FP:              {}'.format(FP))
    print('FN:              {}'.format(FN))
    print('TN:              {}'.format(TN))
    print('precision:       {}'.format(TP / (TP + FP)))
    print('recall:          {}'.format(TP / (TP + FN)))
    print('accuracy:        {}'.format((TP + TN) / total))
    print('auroc:           {}'.format(auroc))

def with_custom_prediction(predictions, threshold):

    def apply_custom_threshold(probability, threshold):
        return int(probability[1] > threshold)

    apply_custom_threshold_udf = udf(lambda x: apply_custom_threshold(x, threshold), IntegerType())

    return predictions.withColumn("customPrediction", apply_custom_threshold_udf(col("probability")))

predictions = with_custom_prediction(predictions, 0.99999)
print_binary_metrics(predictions, predictionCol="customPrediction")


       
##################################### Hyperparameter Tuning using Logistic regression #############################

from pyspark.ml.tuning import ParamGridBuilder, CrossValidator

# Create ParamGrid for Cross Validation
paramGrid = (ParamGridBuilder()
             .addGrid(lr.regParam,[0.01, 0.5, 2.0]) # regularization parameter
             .addGrid(lr.elasticNetParam,[0.0, 1.0]) # Elastic Net Parameter (Ridge = 0)
             .addGrid(lr.maxIter, [10, 100, 1000]) #Number of iterations
             .build())
           
# Create 5-fold CrossValidator
cv = CrossValidator(estimator=lr, 
                    estimatorParamMaps=paramGrid, 
                    evaluator= evaluator, 
                    numFolds=5)
cvModel = cv.fit(train)

predictions = cvModel.transform(test)
# Evaluate best model
evaluator = BinaryClassificationEvaluator()
evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"})


## With hyperparameter tuning 

# ROC = 0.7383256535483098
# Summary Stats
# Precision = 0.6908568573569822
# Recall = 0.18253522986040066
# F1 Score = 0.28877228704936436
# Out[51]:
# array([[49884.,  2475.],
       # [24770.,  5531.]])
       
############################### RandomForestClassifier with class Imbalance ########################################


#from pyspark.ml.evaluation import BinaryClassificationEvaluator
#from pyspark.ml.classification import RandomForestClassifier

# Fitting the model
#rf = RandomForestClassifier(featuresCol = 'features', labelCol = 'label')
#rfModel = rf.fit(train)
#predictions = rfModel.transform(test)
#predictions.select('label', 'rawPrediction', 'prediction', 'probability').show(10)

#evaluator = BinaryClassificationEvaluator()
#print("Test Area Under ROC: " + str(evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"})))

# --> 0.6755888328365299

########################################## Random Forest Without Hyperparameter ##################################

## Stratified sampling ##

# counts = dataset.select('label').groupBy('label').count()

# # +-----+------+
# # |label| count|
# # +-----+------+
# # |    0|373266|
# # |    1| 40027|
# # +-----+------+

# thisdict =	{
  # 0: 0.7,
  # 1: 0.7
  # }

# train = dataset.stat.sampleBy("label",fractions = thisdict,seed = 100)

# test = dataset.subtract(train)

## Downsampling and upsampling  - resampling ###

from numpy.random import randint
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType
from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame

train00 = (train.filter(F.col("label") == 0))
train11 = (train.filter(F.col("label") == 1))

train0_df = train00.sample(False, .6, 12345)
train1_df = train11.sample(True, 2.0, 12345)

train_df = unionAll(train0_df,train1_df)
counts = train_df.select('label').groupBy('label').count()



# +-----+------+
# |label| count|
# +-----+------+
# |    0|178635|
# |    1| 63610|
# +-----+------+


from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.classification import RandomForestClassifier

# Fitting the model
rf = RandomForestClassifier(featuresCol = 'features', labelCol = 'label')
rfModel = rf.fit(train_df)
predictions = rfModel.transform(test)
predictions.select('label', 'rawPrediction', 'prediction', 'probability').show(10)

evaluator = BinaryClassificationEvaluator()
print("Test Area Under ROC: " + str(evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"})))

# -->  0.7740343809452515

################################### Random Forest Hyper Parameter Tuning with cross validation #######################################

from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.classification import RandomForestClassifier


rf = RandomForestClassifier(featuresCol = 'features', labelCol = 'label')
paramGrid = (ParamGridBuilder()
             .addGrid(rf.numTrees, [50,100,200])
             .addGrid(rf.maxDepth, [5, 10, 20]) # depth can be increased and checked
             .build())
evaluator = BinaryClassificationEvaluator()
cv = CrossValidator(estimator=rf, estimatorParamMaps=paramGrid, evaluator=evaluator, numFolds=5)

cvModel = cv.fit(train_df)

predictions = cvModel.transform(test)
evaluator = BinaryClassificationEvaluator()
print("Test Area Under ROC: " + str(evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"})))

# --> 0.8001028812800077 

############################### Metrics Calculation of RandomForestClassifier #################################

from pyspark.mllib.evaluation import MulticlassMetrics

def getrdd(predictions):
    predictions = (predictions.select("label","prediction").withColumn("label", predictions["label"].cast(DoubleType())).rdd
                   )
         
      
    return predictions
 
predictionAndLabels = getrdd(predictions)

# Instantiate metrics object
metrics = MulticlassMetrics(predictionAndLabels)

# Overall statistics
precision = metrics.precision(1)
recall = metrics.recall(1)
f1Score = metrics.fMeasure(1.0)
print("Summary Stats")
print("Precision = %s" % precision)
print("Recall = %s" % recall)
print("F1 Score = %s" % f1Score)
MulticlassMetrics(predictionAndLabels).confusionMatrix().toArray()



##### With class Imbalance #####

# Summary Stats
# Precision = 0.11082505823219321
# Recall = 0.4937192790824686
# F1 Score = 0.5678107944208611
# Out[184]:
# array([[45912.,  7253.],
       # [  450.,   904.]])



###### Without class imbalance without hyperparameter Using Both upsampling and downsampling ######

# Summary Stats
# Precision = 0.4543653250773994
# Recall = 0.31066892464013546
# F1 Score = 0.8492200831590838
# Out[86]:
# array([[66998.,  4406.],
       # [ 8141.,  3669.]])

#### without class imbalance  only downsampling without hyperparameter #####

# Summary Stats                                                                   ]
# Precision = 0.2790581162324649
# Recall = 0.4236546872028903
# F1 Score = 0.8936687722355333
# Out[179]:
# array([[71623.,  5756.],
       # [ 3031.,  2228.]])

############ without class imbalance using hyperparameter tuning max_depth as 5 - kept fixed #############

# Summary Stats
# Precision = 0.23004813782619712
# Recall = 0.4421719016313611
# F1 Score = 0.898346876556256
# Out[23]:
# array([[72144.,  6078.],
       # [ 2291.,  1816.]])

############ without class imbalance using hyperparameter tuning max_depth as [5, 10, 20] #############

# Summary Stats
# Precision = 0.3744616164175323
# Recall = 0.37389324563622567
# F1 Score = 0.8798965127719273
# Out[25]:
# array([[69485.,  4938.],
       # [ 4950.,  2956.]])

######################## without class imbalance using hyperparameter tuning max_depth as [5, 10, 20] Using downsampling alone #########

# Summary Stats
# Precision = 0.5190017734988599
# Recall = 0.29170523317906727
# F1 Score = 0.8330478932089543
# Out[32]:
# array([[64487.,  3797.],
       # [ 9948.,  4097.]])
       
########################## After PCA pre-process, hyperparameter, downsampling and upsampling ################

# ROC -  0.6397051539945225

# Summary Stats
# Precision = 0.47009803921568627
# Recall = 0.2042381003088063
# F1 Score = 0.5167775475333551
# Out[112]:
# array([[38809.,  4324.],
       # [ 7560.,  3836.]])


########################################### Gradient Boosting ###########################################

## Re-sampling in Gradient boosting

# counts = dataset.select('label').groupBy('label').count()

# # +-----+------+
# # |label| count|
# # +-----+------+
# # |    0|373266|
# # |    1| 40027|
# # +-----+------+



# thisdict =	{
  # 0: 0.7,
  # 1: 0.7
  # }

# train = dataset.stat.sampleBy("label",fractions = thisdict,seed = 100)

# test = dataset.subtract(train)

## Downsampling and upsampling  - resampling ###

from numpy.random import randint
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType
from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame

def unionAll(*dfs):
     return reduce(DataFrame.unionAll, dfs)

train00 = (train.filter(F.col("label") == 0))
train11 = (train.filter(F.col("label") == 1))

train0_df = train00.sample(False, .6, 12345)
train1_df = train11.sample(True, 2.0, 12345)

train_df = unionAll(train0_df,train1_df)
counts = train_df.select('label').groupBy('label').count()



# +-----+------+
# |label| count|
# +-----+------+
# |    0|178635|
# |    1| 63610|
# +-----+------+

################# upsampling and downsampling using exploding ####### (NOT YET IMPLEMENTED)

training_downsampled = (
    train
    .withColumn("Random", rand())
    .where((col("Class") != 0) | ((col("Class") == 0) & (col("Random") < 2 * (492 / 284315))))
)
training_downsampled.cache()

print_class_balance(training_downsampled, "training_downsampled")

# Randomly upsample by exploding a vector of length betwen 0 and n for each row (NOT YET IMPLEMENTED)

ratio = 10
n = 20
p = ratio / n  # ratio < n such that probability < 1

def random_resample(x, n, p):
    # Can implement custom sampling logic per class,
    if x == 0:
        return [0]  # no sampling
    if x == 1:
        return list(range((np.sum(np.random.random(n) > p))))  # upsampling
    return []  # drop

random_resample_udf = udf(lambda x: random_resample(x, n, p), ArrayType(IntegerType()))

training_resampled = (
    training
    .withColumn("Sample", random_resample_udf(col("Class")))
    .select(
        col("Time"),
        col("Features"),
        col("Class"),
        explode(col("Sample")).alias("Sample")
    )
    .drop("Sample")
)

###################### Without Hyperparameter Tuning ##################

from pyspark.ml.classification import GBTClassifier
gbt = GBTClassifier(maxIter=10)
gbtModel = gbt.fit(train_df)
predictions = gbtModel.transform(test)
predictions.select('label', 'prediction', 'probability','rawPrediction').show(10)

evaluator = BinaryClassificationEvaluator()
print("Test Area Under ROC: " + str(evaluator.evaluate(predictions, {evaluator.metricName: "areaUnderROC"})))

# ROC: 0.793713522825304
# Summary Stats
# Precision = 0.37784161878591055
# Recall = 0.37708800797806036
# F1 Score = 0.377464437234839
# Out[66]:
# array([[69657.,  4981.],
       # [ 4997.,  3025.]])

######################## Predicting  Gradient Boosting using cross validation for hyperparameter tuning ###########################################

from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.classification import GBTClassifier
from pyspark.ml.classification import GBTClassifier

gbt = GBTClassifier()
paramGrid = (ParamGridBuilder()
             .addGrid(gbt.maxDepth, [2, 4, 6]) # increasing the depth might perform well. however this range could be given as varied such as 10, 50, 100 to check which depth is optimum
             .addGrid(gbt.maxBins, [20, 60])
             .addGrid(gbt.maxIter, [10, 20])
             .build())
cv = CrossValidator(estimator=gbt, estimatorParamMaps=paramGrid, evaluator=evaluator, numFolds=5)
cvModel = cv.fit(train_df)

predictions = cvModel.transform(test)
evaluator.evaluate(predictions)
# -->  ROC = 0.8122251039436328

## Output with hyper parameter tuning ##

# Summary Stats                                                                   ]
# Precision = 0.5192307692307693
# Recall = 0.340603890290551
# F1 Score = 0.4138
# Out[138]:
# array([[66466.,  3875.],
       # [ 8102.,  4185.]])


############################# Metrics for Gradient Boosting ###################################

from pyspark.mllib.evaluation import MulticlassMetrics

def getrdd(predictions):
    predictions = (predictions.select("label","prediction").withColumn("label", predictions["label"].cast(DoubleType())).rdd
                   )
         
      
    return predictions
 
predictionAndLabels = getrdd(predictions)

# Compute raw scores on the test set
# predictionAndLabels = testrdd.map(lambda lp: (float(lrModel.predict(lp.features)), lp.label))

# Instantiate metrics object
metrics = MulticlassMetrics(predictionAndLabels)

# Overall statistics
precision = metrics.precision(1)
recall = metrics.recall(1)
f1Score = metrics.fMeasure(1.0)
print("Summary Stats")
print("Precision = %s" % precision)
print("Recall = %s" % recall)
print("F1 Score = %s" % f1Score)
MulticlassMetrics(predictionAndLabels).confusionMatrix().toArray()



############################################ Question 3(b) ######################################################

########################################################## pre-processing Steps #########################################################

from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml import Pipeline

stages = []
label_stringIdx = StringIndexer(inputCol = 'genre', outputCol = 'label')
stages += [label_stringIdx]

data = (Joined_Table.na.drop().drop("track_id","MSD_TRACKID"))
col = data.drop("genre","label").columns
amt_assembler = VectorAssembler(inputCols = col,outputCol ="features")
stages += [amt_assembler]

pipeline = Pipeline(stages = stages)
pipelineFit = pipeline.fit(data)
dataset = pipelineFit.transform(data)

################################################## Splitting the Data (Taking Class Imbalance into Account) ###############################

################ Stratified Sampling using SampleBy method ##################

from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame
from pyspark.sql.functions import lit


thisdict =	{
  0: 0.7,
  1: 0.7,
  2: 0.7,
  3: 0.7,
  4: 0.7,
  5: 0.7,
  6: 0.7,
  7: 0.7,
  8: 0.7,
  9: 0.7,
  10: 0.7,
  11: 0.7,
  12: 0.7,
  13: 0.7,
  14: 0.7,
  15: 0.7,
  16: 0.7,
  17: 0.7,
  18: 0.7,
  19: 0.7,
  20: 0.7
  
}
train = dataset.stat.sampleBy("label",fractions = thisdict,seed = 100)
test = dataset.subtract(train)


counts = train.select('label').groupBy('label').count()

############################ Using Exact Stratification Using Window function #######

temp = (
    dataset
    .withColumn("id", monotonically_increasing_id())
    .withColumn("Random", rand())
    .withColumn(
        "Row",
        row_number()
        .over(
            Window
            .partitionBy("label")
            .orderBy("Random")
        )
    )
)

class_counts = (
    dataset
    .groupBy("label")
    .count()
    .toPandas()
    .set_index("label")["count"]
    .to_dict()
)
classes = sorted(class_counts.keys())

train = temp
for i in classes:
    train = train.where((F.col("label") != i) | (F.col("Row") < class_counts[i] * 0.8))

train.cache()

test = temp.join(train, on="id", how="left_anti")
test.cache()

train = train.drop("id", "Random", "Row")
test = test.drop("id", "Random", "Row")

print_class_balance(dataset, "dataset")
print_class_balance(train, "train")
print_class_balance(test, "test")

########################## Upsampling and downsampling for class imbalance Problem ########################

def unionAll(*dfs):
     return reduce(DataFrame.unionAll, dfs)

counts = train.select('label').groupBy('label').count()
train0 = (train.filter(F.col("label").isin([0])))
train1 = (train.filter(F.col("label").isin([1])))
train2 = (train.filter(F.col("label").isin([2,3,6])))
train3 = (train.filter(F.col("label").isin([7,8,9,10,11,12,13,14])))
train4 = (train.filter(F.col("label").isin([17])))
train5 = (train.filter(F.col("label").isin([4,5])))
train6 = (train.filter(F.col("label").isin([15,16])))
train7 = (train.filter(F.col("label").isin([18,19,20])))

train0_df = train0.sample(False, 20000/185986, 12345)
train1_df= train1.sample(False, 20000/32000, 12345)
train2_df = train2.sample(True, 20000/16000, 12345)
train3_df = train3.sample(True, 4.0, 12345)
train4_df = train4.sample(True, 8.0, 12345)
train5_df = train5.sample(True, 20000/11000, 12345)
train6_df = train6.sample(True, 20000/1200, 12345)
train7_df = train7.sample(True, 20000/200, 12345)

#train1_df = (unionAll(train1,train1))
#train2_df = (unionAll(train2,train2,train2,train2))

train_df = (unionAll(train0_df,train1_df,train2_df,train3_df,train4_df,train5_df,train6_df,train7_df))

counts = train_df.select('label').groupBy('label').count()

#################### One vs All Random Forest Multiclass classifier Implementation ######################

from pyspark.ml.classification import RandomForestClassifier, OneVsRest
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator

rf = RandomForestClassifier(maxDepth=5,  maxBins=32, numTrees=20, seed=123)
ovr_rf = OneVsRest(classifier=rf)

ovr_rfModel = ovr_rf.fit(train_df)


#prediction and calculating accuracy
predictions = ovr_rfModel.transform(test)
evaluator.evaluate(predictions)
# 0.2319909339559767

##################################################### RandomForestClassifier ##################################################

############################################################### Random Forest with hyperparameter tuning ###############################################


from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator

rf = RandomForestClassifier(featuresCol = 'features', labelCol = 'label')
paramGrid = (ParamGridBuilder()
             .addGrid(rf.numTrees, [5,10,20]) ## --> Also checked with [100, 200, 250] -- not much change
             .addGrid(rf.maxDepth, [5,10])
             .build())
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
evaluator = MulticlassClassificationEvaluator()
cv = CrossValidator(estimator=rf, estimatorParamMaps=paramGrid, evaluator=evaluator, numFolds=5)

cvModel = cv.fit(train_df)

predictions = cvModel.transform(test)
selected = predictions.select("label", "prediction", "probability")

evaluator.evaluate(predictions)

--> 0.26910027901177475

################################## Results after Applying PCA Features #########################



# ## AFter PCA 
# In [119]: Precision
# Out[119]: 0.17807553738412338

# In [120]: Recall
# Out[120]: 0.5429523574426067

TP = selected.filter(F.col('prediction') == F.col('label')).count()
Total = selected.count()
Accuracy = TP/Total
# --> 0.5035785961264115

########################## confusion matrix ##########################

from pyspark.mllib.evaluation import MulticlassMetrics

def getrdd(predictions):
    predictions = (predictions.select("label","prediction").withColumn("label", predictions["label"].cast(DoubleType())).rdd
                   )
         
      
    return predictions
 
predictionAndLabels = getrdd(predictions)

# Instantiate metrics object
metrics = MulticlassMetrics(predictionAndLabels)

# Overall statistics


for i in range(0,3):
    precision0 = metrics.precision(i)
    recall0 = metrics.recall(i)
    j = float(i)
    f1Score = metrics.fMeasure(j)
    print("Summary Stats %d"%(i))
    print("Precision = %s" % precision0)
    print("Recall = %s" % recall0)
    print("F1 Score = %s" % f1Score)

############################# With hyper parameter tuning When class imbalance issue still persists as the ratio of upsampling and downsampling is not proper ###################
    
Summary Stats 0
Precision = 0.20853770856983742
Recall = 0.9140067592940293
F1 Score = 0.3395943424196446
Summary Stats 1
Precision = 0.11556006082108464
Recall = 0.4314096499526963
F1 Score = 0.18229062562462522
Summary Stats 2
Precision = 0.5403304178814383
Recall = 0.2263613231552163
F1 Score = 0.31905889104081486
Summary Stats 6
Precision = 0.0
Recall = 0.0
F1 Score = 0.0
Summary Stats 7
Precision = 0.7037815126050421
Recall = 0.053934827408552294
F1 Score = 0.10019141045579616
Summary Stats 8
Precision = 0.3206997084548105
Recall = 0.03417847377578921
F1 Score = 0.06177345987532993
Summary Stats 9
Precision = 0.23956043956043957
Recall = 0.06030984876429362
F1 Score = 0.09636068955355828
Summary Stats 10
Precision = 0.006097560975609756
Recall = 0.06451612903225806
F1 Score = 0.011142061281337047
Summary Stats 11
Precision = 0.2399342645850452
Recall = 0.06323083585967952
F1 Score = 0.10008568980291345
Summary Stats 12
Precision = 0.005240174672489083
Recall = 0.04316546762589928
F1 Score = 0.009345794392523364
Summary Stats 13
Precision = 0.35233160621761656
Recall = 0.12040725984949092
F1 Score = 0.17947871989442427
Summary Stats 17
Precision = 0.0106951871657754
Recall = 0.125
F1 Score = 0.019704433497536946


############################ Results with hyperparameter and further defining the ratio for upsampling and downsampling (Getting all classification for all the classes)#####################

Summary Stats 0
Precision = 0.2122593141164407
Recall = 0.9255993044342318
F1 Score = 0.3453277416066174
Summary Stats 1
Precision = 0.24765964560347709
Recall = 0.402745684382221
F1 Score = 0.3067129030588479
Summary Stats 2
Precision = 0.47248727735368956
Recall = 0.2820926699582226
F1 Score = 0.3532699167657551
Summary Stats 3
Precision = 0.033478343105731036
Recall = 0.25177809388335703
F1 Score = 0.059098497495826366
Summary Stats 4
Precision = 0.14332247557003258
Recall = 0.09540816326530613
F1 Score = 0.11455701049084922
Summary Stats 5
Precision = 0.0009411764705882353
Recall = 0.057971014492753624
F1 Score = 0.0018522806205140078
Summary Stats 6
Precision = 0.04856027330405076
Recall = 0.2926470588235294
F1 Score = 0.08329845123482629
Summary Stats 7
Precision = 0.4569845435987168
Recall = 0.06246761012557305
F1 Score = 0.10991092095111174
Summary Stats 8
Precision = 0.22196969696969698
Recall = 0.04326639102185469
F1 Score = 0.07241720217498764
Summary Stats 9
Precision = 0.31680713931581556
Recall = 0.07096057745696835
F1 Score = 0.11594991834512793
Summary Stats 10
Precision = 0.11660268714011517
Recall = 0.06186354378818737
F1 Score = 0.0808383233532934
Summary Stats 11
Precision = 0.10106951871657754
Recall = 0.10227272727272728
F1 Score = 0.10166756320602474
Summary Stats 12
Precision = 0.009221902017291067
Recall = 0.045584045584045586
F1 Score = 0.015340364333652923
Summary Stats 13
Precision = 0.11418685121107267
Recall = 0.19158200290275762
F1 Score = 0.14308943089430895
Summary Stats 14
Precision = 0.28401360544217685
Recall = 0.22177954847277556
F1 Score = 0.24906785980611487
Summary Stats 15
Precision = 0.2842535787321063
Recall = 0.03682119205298013
F1 Score = 0.06519699812382738
Summary Stats 16
Precision = 0.14187643020594964
Recall = 0.03289124668435013
F1 Score = 0.053402239448751075
Summary Stats 17
Precision = 0.11538461538461539
Recall = 0.07929515418502203
F1 Score = 0.09399477806788512
Summary Stats 18
Precision = 0.4528301886792453
Recall = 0.009046362608367886
F1 Score = 0.01773835920177384
Summary Stats 19
Precision = 0.2896551724137931
Recall = 0.003994293865905849
F1 Score = 0.007879924953095686
Summary Stats 20
Precision = 0.1016949152542373
Recall = 0.0043859649122807015
F1 Score = 0.008409250175192711

######################################## revised hyper parameter tuning numtrees as (100, 200, 250)#############

Summary Stats 0
Precision = 0.21706627638356793
Recall = 0.9335966428042458
F1 Score = 0.3522358173160879
Summary Stats 1
Precision = 0.24213889355977805
Recall = 0.4222873900293255
F1 Score = 0.3077909586405899
Summary Stats 2
Precision = 0.45894667975139025
Recall = 0.283205490512717
F1 Score = 0.3502683809761578
Summary Stats 3
Precision = 0.042682926829268296
Recall = 0.27350427350427353
F1 Score = 0.07384209658809957
Summary Stats 4
Precision = 0.12363707165109035
Recall = 0.09096118034665521
F1 Score = 0.10481142196913426
Summary Stats 5
Precision = 0.0033734939759036144
Recall = 0.13725490196078433
F1 Score = 0.006585136406396989
Summary Stats 6
Precision = 0.03885381253035454
Recall = 0.2831858407079646
F1 Score = 0.06833226564168268
Summary Stats 7
Precision = 0.4565962307252998
Recall = 0.06419366494038299
F1 Score = 0.11256203583119215
Summary Stats 8
Precision = 0.2476340694006309
Recall = 0.04274144150275642
F1 Score = 0.07290034244587615
Summary Stats 9
Precision = 0.2876513317191283
Recall = 0.07019617111793902
F1 Score = 0.1128526645768025
Summary Stats 10
Precision = 0.1455
Recall = 0.06220607097050022
F1 Score = 0.08715184186882301
Summary Stats 11
Precision = 0.089157952669235
Recall = 0.10431423052157116
F1 Score = 0.09614243323442136
Summary Stats 12
Precision = 0.0070880094506792675
Recall = 0.07947019867549669
F1 Score = 0.013015184381778741
Summary Stats 13
Precision = 0.10664335664335664
Recall = 0.17604617604617603
F1 Score = 0.13282525857376157
Summary Stats 14
Precision = 0.25542570951585974
Recall = 0.3
F1 Score = 0.27592425608656446
Summary Stats 15
Precision = 0.2835820895522388
Recall = 0.03433144037170883
F1 Score = 0.06124798526364265
Summary Stats 16
Precision = 0.1416490486257928
Recall = 0.040216086434573826
F1 Score = 0.06264609630668536
Summary Stats 17
Precision = 0.11551155115511551
Recall = 0.09333333333333334
F1 Score = 0.10324483775811209
Summary Stats 18
Precision = 0.5177304964539007
Recall = 0.007542101456762062
F1 Score = 0.014867617107942974
Summary Stats 19
Precision = 0.3092105263157895
Recall = 0.004918890633176348
F1 Score = 0.009683733388276501
Summary Stats 20
Precision = 0.08
Recall = 0.0036363636363636364
F1 Score = 0.006956521739130435

############################################## When using Window Function for stratified Sampling and using revised upsampling and downsampling ######################

Summary Stats 0
Precision = 0.2088412017167382
Recall = 0.9285373533059823
F1 Score = 0.3409891207231829
Summary Stats 1
Precision = 0.2398201348988259
Recall = 0.42790283039893023
F1 Score = 0.3073721283918995
Summary Stats 2
Precision = 0.4679144385026738
Recall = 0.26254773595199127
F1 Score = 0.3363620478769876
Summary Stats 3
Precision = 0.031791087141640646
Recall = 0.24944320712694878
F1 Score = 0.05639476334340383
Summary Stats 4
Precision = 0.10810810810810811
Recall = 0.09703225806451612
F1 Score = 0.10227118183054536
Summary Stats 5
Precision = 0.004626334519572953
Recall = 0.11504424778761062
F1 Score = 0.008894970920287374
Summary Stats 6
Precision = 0.03897509924215085
Recall = 0.2621359223300971
F1 Score = 0.06786050895381715
Summary Stats 7
Precision = 0.4660534384581691
Recall = 0.06270996640537514
F1 Score = 0.11054545454545456
Summary Stats 8

########################################## result for one vs all random forest ###########

Summary Stats 0
Precision = 0.20495708154506437
Recall = 0.9115289177323916
F1 Score = 0.3346648445986194
Summary Stats 1
Precision = 0.3230077441918561
Recall = 0.33937007874015745
F1 Score = 0.33098681684372194
Summary Stats 2
Precision = 0.06781720952843948
Recall = 0.1930795847750865
F1 Score = 0.10037776578521317
Summary Stats 4
Precision = 0.0002875215641173088
Recall = 0.25
F1 Score = 0.0005743825387708214
Summary Stats 5
Precision = 0.00035587188612099647
Recall = 0.1111111111111111
F1 Score = 0.0007094714437743882
Summary Stats 6
Precision = 0.0
Recall = 0.0
F1 Score = 0.0
Summary Stats 7
Precision = 0.44634253175646077
Recall = 0.047627950455713955
F1 Score = 0.0860714587380691
Summary Stats 8
Precision = 0.0997134670487106
Recall = 0.03845303867403315
F1 Score = 0.055502392344497616
Summary Stats 9
Precision = 0.3003636363636364
Recall = 0.061312351543942996
F1 Score = 0.10183701146591051
Summary Stats 10
Precision = 0.0
Recall = 0.0
F1 Score = 0.0
Summary Stats 11
Precision = 0.0
Recall = 0.0
F1 Score = 0.0
Summary Stats 16
Precision = 0.003278688524590164
Recall = 0.1
F1 Score = 0.006349206349206349
Summary Stats 17
Precision = 0.125
Recall = 0.06596306068601583
F1 Score = 0.08635578583765113
Summary Stats 18
Precision = 0.6697247706422018
Recall = 0.0062478603218076
F1 Score = 0.01238022555753413
Summary Stats 19
Precision = 0.34782608695652173
Recall = 0.001789909385837342
F1 Score = 0.003561491374513077
Summary Stats 20
Precision = 0.0
Recall = 0.0
F1 Score = 0.0



############################################################# SONG RECOMMENDATION #######################################
import sys

from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window

from pyspark.ml.recommendation import ALS
from pyspark.ml.evaluation import RegressionEvaluator

from pyspark.mllib.evaluation import RankingMetrics

import numpy as np

# Required to allow the file to be submitted and run using spark-submit instead
# of using pyspark interactively

spark = SparkSession.builder.getOrCreate()
sc = SparkContext.getOrCreate()
        
## Checking the dataset which is loaded previously ##

print(mismatches_not_accepted.count())  # 19093
print(triplets.count())                 # 48373586
print(triplets_not_mismatched.count())  # 45795111

## Question 1(a)

song_counts = (
    triplets_not_mismatched
    .groupBy("song_id")
    .agg(
        count(F.col("user_id")).alias("user_count"),
        sum(F.col("plays")).alias("play_count"),
    )
    .orderBy(F.col("play_count").desc())
)
song_counts.cache()
song_counts.count()

song_counts.write.csv("hdfs:///user/mss152/outputs/song_counts.csv")

# +------------------+----------+----------+
# |           song_id|user_count|play_count|
# +------------------+----------+----------+
# |SOBONKR12A58A7A7E0|     84000|    726885|
# |SOSXLTC12AF72A7F54|     80656|    527893|
# |SOEGIYH12A6D4FC0E3|     69487|    389880|
# |SOAXGDH12A8C13F8A1|     90444|    356533|
# |SONYKOW12AB01849C9|     78353|    292642|
# |SOPUCYA12A8C13A694|     46078|    274627|
# |SOUFTBI12AB0183F65|     37642|    268353|
# |SOVDSJC12A58A7A271|     36976|    244730|
# |SOOFYTN12A6D4F9B35|     40403|    241669|
# |SOHTKMO12AB01843B0|     46077|    236494|
# |SOBOUPA12A6D4F81F1|     41093|    225652|
# |SOLFXKT12AB017E3E0|     64229|    197181|
# |SOTCMDJ12A6D4F8528|     32015|    192884|
# |SOFLJQZ12A6D4FADA6|     58610|    185653|
# |SOTWNDJ12A8C143984|     47011|    174080|
# |SOUNZHU12A8AE47481|     30841|    158636|
# |SOUVTSM12AC468F6A7|     51022|    155717|
# |SOUSMXX12AB0185C24|     53260|    155529|
# |SOUDLVN12AAFF43658|     19842|    146978|
# |SOWCKVR12A8C142411|     52080|    145725|
# +------------------+----------+----------+


triplets_not_mismatched.select("song_id").distinct().count() ## Count of the song IDs
# Out[204]: 378310

user_counts = (
    triplets_not_mismatched
    .groupBy("user_id")
    .agg(
        count(F.col("song_id")).alias("song_count"),
        sum(F.col("plays")).alias("play_count"),
    )
    .orderBy(F.col("play_count").desc())
)
user_counts.cache()
user_counts.count()
user_counts.write.csv("hdfs:///user/mss152/outputs/user_counts.csv")

# user_counts.show()
# +----------------------------------------+----------+----------+
# |user_id                                 |song_count|play_count|
# +----------------------------------------+----------+----------+
# |093cb74eb3c517c5179ae24caf0ebec51b24d2a2|195       |13074     |
# |119b7c88d58d0c6eb051365c103da5caf817bea6|1362      |9104      |
# |3fa44653315697f42410a30cb766a4eb102080bb|146       |8025      |
# |a2679496cd0af9779a92a13ff7c6af5c81ea8c7b|518       |6506      |
# |d7d2d888ae04d16e994d6964214a1de81392ee04|1257      |6190      |
# |4ae01afa8f2430ea0704d502bc7b57fb52164882|453       |6153      |
# |b7c24f770be6b802805ac0e2106624a517643c17|1364      |5827      |
# |113255a012b2affeab62607563d03fbdf31b08e7|1096      |5471      |
# |99ac3d883681e21ea68071019dba828ce76fe94d|939       |5385      |
# |6d625c6557df84b60d90426c0116138b617b9449|1307      |5362      |
# +----------------------------------------+----------+----------+


triplets_not_mismatched.select("user_id").distinct().count() ## Count of the users
# Out[205]: 1019318


# Analysing the DATA

statistics = (
    user_counts
    .select("song_count", "play_count")
    .describe()
    .toPandas()
    .set_index("summary")
    .rename_axis(None)
    .T
)
print(statistics)

#               count                mean              stddev min    max
# song_count  1019318   44.92720721109605   54.91113199747355   3   4316
# play_count  1019318  128.82423149596102  175.43956510304616   3  13074

user_counts.approxQuantile("song_count", [0.0, 0.25, 0.5, 0.75, 1.0], 0.05)
user_counts.approxQuantile("play_count", [0.0, 0.25, 0.5, 0.75, 1.0], 0.05)

# [3.0, 20.0, 32.0,  58.0,  4316.0]
# [3.0, 35.0, 71.0, 173.0, 13074.0]

statistics = (
    song_counts
    .select("user_count", "play_count")
    .describe()
    .toPandas()
    .set_index("summary")
    .rename_axis(None)
    .T
)
print(statistics)

#              count                mean             stddev min     max
# user_count  378310  121.05181200602681  748.6489783736941   1   90444
# play_count  378310   347.1038513388491  2978.605348838212   1  726885

song_counts.approxQuantile("user_count", [0.0, 0.25, 0.5, 0.75, 1.0], 0.05)
song_counts.approxQuantile("play_count", [0.0, 0.25, 0.5, 0.75, 1.0], 0.05)

# [1.0,  5.0, 13.0, 104.0,  90444.0]
# [1.0, 11.0, 36.0, 217.0, 726885.0]

## Question 1(b)

df = (triplets_not_mismatched.
        groupBy("user_id").
        agg({'plays':'sum'}).
            withColumnRenamed("sum(plays)","Play_count").
                orderBy('Play_count', ascending=False))

df.show(truncate = False)

# --> 093cb74eb3c517c5179ae24caf0ebec51b24d2a2

df = (triplets_not_mismatched.
        filter(F.col("user_id") == "093cb74eb3c517c5179ae24caf0ebec51b24d2a2")
     )
        
df = df.select("song_id").distinct()
df.count()

# --> 202 different songs are played by the most active user.
# +------------------+
# |           song_id|
# +------------------+
# |SOAAXEQ12A6D4F7B4C|
# |SOAJVOL12AAF3B25E6|
# |SOAMEVJ12A6701E393|
# |SOAONVU12A6D4F4759|
# |SOAOSDF12A58A779F1|
# |SOARATQ12A6D4F69C7|
# |SOBFSES12A8C140597|
# |SOBVZDO12AB017F590|
# |SOCHSJD12A6D4F926E|
# |SOCHTHF12AB017E206|
# |SODNMQU12AAA15FB31|
# |SOEDZYU12A58A78EB5|
# |SOEOTVW12A8C1454C3|
# |SOFCXNF12A58A7CF16|
# |SOFGKLU12AB018110C|
# |SOFTZIM12A8C142182|
# |SOGDIJP12AB0187D11|
# |SOGKLCX12A6D4F7C32|
# |SOGVXHK12A58A7F522|
# |SOIEGWA12AAF3B3D2A|
# +------------------+

# ----------------------
 # Question 1(c)
# --------------------------

### Song_id distribution ###

df1 = (triplets_not_mismatched.
        groupBy("song_id").
        agg({'plays':'sum'}).
        withColumnRenamed("sum(plays)","Play_count").
        orderBy('Play_count', ascending=False))
        
# df1.write.csv("hdfs:///user/mss152/outputs/hist_song_id.csv")     

# hdfs dfs -copyToLocal "hdfs:///user/mss152/outputs/hist_song_id.csv")
# +------------------+----------+
# |           song_id|Play_count|
# +------------------+----------+
# |SOBONKR12A58A7A7E0|    726885|
# |SOSXLTC12AF72A7F54|    527893|
# |SOEGIYH12A6D4FC0E3|    389880|
# |SOAXGDH12A8C13F8A1|    356533|
# |SONYKOW12AB01849C9|    292642|
# |SOPUCYA12A8C13A694|    274627|
# |SOUFTBI12AB0183F65|    268353|
# |SOVDSJC12A58A7A271|    244730|
# |SOOFYTN12A6D4F9B35|    241669|
# |SOHTKMO12AB01843B0|    236494|
# |SOBOUPA12A6D4F81F1|    225652|
# |SOLFXKT12AB017E3E0|    197181|
# |SOTCMDJ12A6D4F8528|    192884|
# |SOFLJQZ12A6D4FADA6|    185653|
# |SOTWNDJ12A8C143984|    174080|
# |SOUNZHU12A8AE47481|    158636|
# |SOUVTSM12AC468F6A7|    155717|
# |SOUSMXX12AB0185C24|    155529|
# |SOUDLVN12AAFF43658|    146978|
# |SOWCKVR12A8C142411|    145725|
# +------------------+----------+


### user_id distribution ###

df2 = (triplets_not_mismatched.
        groupBy("user_id").
        agg({'plays':'sum'},{'song_id':'count'}).
        withColumnRenamed("sum(plays)","Play_count").
        orderBy('Play_count', ascending=False))
        
df2.write.csv("hdfs:///user/mss152/outputs/hist_user_id.csv")     

# hdfs dfs -copyToLocal "hdfs:///user/mss152/outputs/hist_user_id.csv")

                              

# ----------------
# Question 1(d)  Creating a clean dataset after deciding the threshold limit
# -----------------


# ## Songs played less than 10 times and user who listened to fewer than 8 songs --> Not used 

# song_id = triplets_not_mismatched.groupby("song_id").agg({'plays':'sum'},{'user_id':'count'}).withColumnRenamed("sum(plays)","Play_count").filter(F.col('Play_count') < 10)
# user_id = triplets_not_mismatched.groupby("user_id").agg({'plays':'sum'},{'song_id':'count'}).withColumnRenamed("sum(plays)","Play_count").filter(F.col('Play_count') < 8)

# triplets_not_mismatched = triplets_not_mismatched.join(song_id, on="song_id", how="left_anti")
# triplets_not_mismatched = triplets_not_mismatched.join(user_id, on="user_id", how="left_anti")

user_song_count_threshold = 10
song_user_count_threshold = 6 

triplets_limited = triplets_not_mismatched.repartition(128)

def get_user_counts(triplets):
    return (
        triplets
        .groupBy("user_id")
        .agg(
            F.count(col("song_id")).alias("song_count"),
            F.sum(col("plays")).alias("play_count"),
        )
        .orderBy(col("play_count").desc())
    )

def get_song_counts(triplets):
    return (
        triplets
        .groupBy("song_id")
        .agg(
            F.count(col("user_id")).alias("user_count"),
            F.sum(col("plays")).alias("play_count"),
        )
        .orderBy(col("play_count").desc())
    )

for i in range(0, 7):  ## Taking only 5 iterations as more number of iterations is taking too much time

    triplets_limited = (
        triplets_limited
        .join(
            triplets_limited.groupBy("user_id").count().where(F.col("count") > user_song_count_threshold).select("user_id"),
            on="user_id",
            how="inner"
        )
    )

    triplets_limited = (
        triplets_limited
        .join(
            triplets_limited.groupBy("song_id").count().where(F.col("count") > song_user_count_threshold).select("song_id"),
            on="song_id",
            how="inner"
        )
    )
   

triplets_limited.cache()
triplets_limited.count()

# 44601834

(
    triplets_limited
    .agg(
        countDistinct(col("user_id")).alias('user_count'),
        countDistinct(col("song_id")).alias('song_count')
    )
    .toPandas()
    .T
    .rename(columns={0: "value"})
)

             # value
# user_count  936543 /1019318 = 0.918
# song_count  262037 /378310 = 0.69


print(get_user_counts(triplets_limited).approxQuantile("song_count", [0.0, 0.25, 0.5, 0.75, 1.0], 0.05))
print(get_song_counts(triplets_limited).approxQuantile("user_count", [0.0, 0.25, 0.5, 0.75, 1.0], 0.05))

[11.0, 20.0, 32.0, 65.0, 4006.0]
[7.0, 18.0, 39.0, 123.0, 86599.0]


from pyspark.ml.feature import StringIndexer
from pyspark.ml import Pipeline

stages = []
label_stringIdx = StringIndexer(inputCol = 'user_id', outputCol = 'user_id_encoded')
label_stringIdx1 = StringIndexer(inputCol = 'song_id', outputCol = 'song_id_encoded')
stages += [label_stringIdx, label_stringIdx1]

pipeline = Pipeline(stages = stages)
pipelineFit = pipeline.fit(triplets_limited)
triplets_limited = pipelineFit.transform(triplets_limited)


# ALS

########################### Splitting the Dataset ##################

(trainingData, testData) = triplets_limited.randomSplit([0.7, 0.3]) 
test_not_training = testData.join(trainingData, on="user_id", how="left_anti")

trainingData.cache()
testData.cache()
test_not_training.cache() 

print(f"training:          {trainingData.count()}")
print(f"test:              {testData.count()}")
print(f"test_not_training: {test_not_training.count()}")

# training:          31293748
# test:              13403642
# test_not_training: 0

# If test_not_training does not come as 0 we can drop it 

testData = (testData.join(test_not_training, on="song_id", how="left_anti"))

#### Checking if the test contains 20% of the plays in total. #####

# testData.select("song_id").distinct().count()
# 257520
# Total distinct song count for triplets_not_mismatched
# 378310
# trainingData.select("song_id").distinct().count()
# 262019
# Total sum of plays in the datatset- 130881791
# Total sum of plays in Test data - 39250151

#trainingData.cache()
#testData.cache()



#----------
# Imports
#----------

from pyspark.ml.recommendation import ALS
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.feature import StringIndexer

from pyspark.mllib.evaluation import RankingMetrics

# -----------------
# Modelling
# -----------------

als = ALS(maxIter=10, regParam=0.01, userCol="user_id_encoded", itemCol="song_id_encoded", ratingCol="plays")
alsModel = als.fit(trainingData)
predictions = alsModel.transform(testData)

predictions = predictions.orderBy(F.col("user_id"), F.col("song_id"), F.col("prediction").desc())
predictions.cache()

predictions.show(50, False)

# +------------------+----------------------------------------+-----+---------------+---------------+------------+
# |song_id           |user_id                                 |plays|user_id_encoded|song_id_encoded|prediction  |
# +------------------+----------------------------------------+-----+---------------+---------------+------------+
# |SOBQJJX12A6D4F7F01|00000b722001882066dff9d2da8a775658053ea0|2    |861040.0       |12817.0        |2.0716062   |
# |SOCTXQW12A6D4F70AD|00000b722001882066dff9d2da8a775658053ea0|1    |861040.0       |33820.0        |0.4759907   |
# |SOCZQCY12AC468E40F|00000b722001882066dff9d2da8a775658053ea0|1    |861040.0       |12993.0        |-0.07071537 |
# |SOKBXYC12A6D4F59D6|00000b722001882066dff9d2da8a775658053ea0|1    |861040.0       |41114.0        |0.197362    |
# |SOMRTLE12A58A78D26|00000b722001882066dff9d2da8a775658053ea0|1    |861040.0       |38846.0        |0.42546672  |
# |SORDKNX12A8C13A45F|00000b722001882066dff9d2da8a775658053ea0|1    |861040.0       |50654.0        |1.0487847   |
# |SOFXSRW12A6D4F3B77|00001638d6189236866af9bbf309ae6c2347ffdc|1    |787947.0       |22752.0        |14.28672    |
# |SOLOYFG12A8C133391|00001638d6189236866af9bbf309ae6c2347ffdc|1    |787947.0       |19781.0        |0.52441     |
# |SOOEPEG12A6D4FC7CA|00001638d6189236866af9bbf309ae6c2347ffdc|1    |787947.0       |4703.0         |8.965619    |
# |SOPFRAN12A8C13AA77|00001638d6189236866af9bbf309ae6c2347ffdc|2    |787947.0       |35565.0        |1.1674563   |
# |SOACWNM12AB0182F2D|0000175652312d12576d9e6b84f600caa24c4715|1    |862321.0       |22751.0        |-2.3991117  |
# |SOBYRTY12AB0181EDB|0000175652312d12576d9e6b84f600caa24c4715|1    |862321.0       |7819.0         |1.2602521   |
# |SOPOLHW12A6D4F7DC4|0000175652312d12576d9e6b84f600caa24c4715|1    |862321.0       |19100.0        |-9.912369   |
# |SOYWZXA12A8C138274|0000175652312d12576d9e6b84f600caa24c4715|1    |862321.0       |16681.0        |1.0457916   |
# |SOGBGBT12AB01809B3|00001cf0dce3fb22b0df0f3a1d9cd21e38385372|1    |688087.0       |4385.0         |1.361373    |
# |SOLOVPR12AB0182D03|00001cf0dce3fb22b0df0f3a1d9cd21e38385372|2    |688087.0       |3322.0         |1.120191    |
# |SOLVTNS12AB01809E2|00001cf0dce3fb22b0df0f3a1d9cd21e38385372|2    |688087.0       |5766.0         |0.6884965   |
# |SOUPXLX12A67ADE83A|00001cf0dce3fb22b0df0f3a1d9cd21e38385372|1    |688087.0       |11871.0        |0.94364345  |
# |SOXCMGF12A67ADE833|00001cf0dce3fb22b0df0f3a1d9cd21e38385372|1    |688087.0       |11542.0        |1.3397573   |
# |SOLWRQM12AB0184C86|0000267bde1b3a70ea75cf2b2d216cb828e3202b|1    |553365.0       |1099.0         |0.95896745  |
# |SOQLDTI12AB018C80A|0000267bde1b3a70ea75cf2b2d216cb828e3202b|1    |553365.0       |2833.0         |1.8995717   |
# |SORHJAS12AB0187D3F|0000267bde1b3a70ea75cf2b2d216cb828e3202b|1    |553365.0       |1048.0         |0.999522    |
# |SOTDKEJ12AB0187AAA|0000267bde1b3a70ea75cf2b2d216cb828e3202b|2    |553365.0       |432.0          |1.2385215   |
# |SOCEQVU12A6D4F78B3|00003a4459f33b92906be11abe0e93efc423c0ff|3    |788049.0       |21467.0        |2.2337518   |
# |SOEOODW12AB017A9FB|00003a4459f33b92906be11abe0e93efc423c0ff|1    |788049.0       |127407.0       |3.28296     |
# |SOVGREU12A8AE4751A|00003a4459f33b92906be11abe0e93efc423c0ff|1    |788049.0       |52828.0        |6.176786    |
# |SOGDQWF12A67AD954F|00004fb90a86beb8bed1e9e328f5d9b6ee7dc03e|1    |325378.0       |2497.0         |0.81716263  |
# |SOGIDSA12A8C142829|00004fb90a86beb8bed1e9e328f5d9b6ee7dc03e|3    |325378.0       |805.0          |1.0263503   |
# |SOGXWGC12AF72A8F9A|00004fb90a86beb8bed1e9e328f5d9b6ee7dc03e|1    |325378.0       |2016.0         |0.9463761   |
# |SOKUECJ12A6D4F6129|00004fb90a86beb8bed1e9e328f5d9b6ee7dc03e|1    |325378.0       |193.0          |1.0141938   |
# |SOPDRWC12A8C141DDE|00004fb90a86beb8bed1e9e328f5d9b6ee7dc03e|1    |325378.0       |338.0          |1.6780049   |
# |SOSXLTC12AF72A7F54|00004fb90a86beb8bed1e9e328f5d9b6ee7dc03e|1    |325378.0       |2.0            |1.675181    |
# |SOGMLQO12A670207BF|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |1449.0         |0.6328239   |
# |SOGNVXA12A8C14373F|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |6969.0         |-0.21696606 |
# |SOHCOVJ12A8C137A8E|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |41305.0        |1.6551788   |
# |SOHYFGY12A6D4F8E3E|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |50035.0        |0.52572566  |
# |SOIOZIK12AB018B44D|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |105360.0       |0.9952286   |
# |SORGGRV12A8AE477C0|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|2    |774056.0       |6353.0         |-0.025574327|
# |SORXKRH12A8AE47CEF|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |10373.0        |-0.26109242 |
# |SOSDORC12A8C14649E|00005c6177188f12fb5e2e82cdbd93e8a3f35e64|1    |774056.0       |16664.0        |0.7788682   |
# |SOAPSFK12AC46890F8|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |9159.0         |3.1334047   |
# |SOBNOGD12AC90971C5|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |33408.0        |3.2175136   |
# |SOHLBZD12A58A7B0AC|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |5256.0         |1.6714488   |
# |SOILWTV12A6D4F4A4B|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |6277.0         |0.7062952   |
# |SOKXYIL12AB0189157|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|2    |416079.0       |7173.0         |1.3586383   |
# |SONBIEE12A58A7BE55|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |1271.0         |3.1405337   |
# |SONSHOY12A8C13E81D|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |82006.0        |3.4044251   |
# |SOTFQUH12A58A7AE05|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |25416.0        |-8.700241   |
# |SOYOKCE12A58A79862|000060ca4e6bea0a5c9037fc1bbd7bbabb98c754|1    |416079.0       |1572.0         |1.4876204   |
# |SOANVMB12AB017F1DD|00007ed2509128dcdd74ea3aac2363e24e9dc06b|1    |229523.0       |88115.0        |0.8836605   |
+------------------+----------------------------------------+-----+---------------+---------------+------------+



# -----------------------------------------------------------------------------
# Metrics
# -----------------------------------------------------------------------------

# Code for generating recommendations 

def extract_songs_top_k(x, k):
    x = sorted(x, key=lambda x: -x[1])
    return [x[0] for x in x][0:k]

extract_songs_top_k_udf = udf(lambda x: extract_songs_top_k(x, k), ArrayType(IntegerType()))

def extract_songs(x):
    x = sorted(x, key=lambda x: -x[1])
    return [x[0] for x in x]

extract_songs_udf = udf(lambda x: extract_songs(x), ArrayType(IntegerType()))

k = 5  # For 10 recommendations this value should be kept as 10

topK = alsModel.recommendForAllUsers(k)

topK.cache()
topK.count()

935642

topK.show(10, False)

# +---------------+-------------------------------------------------------------------------------------------------------+
# |user_id_encoded|recommendations                                                                                        |
# +---------------+-------------------------------------------------------------------------------------------------------+
# |12             |[[71773, 567.7501], [134956, 443.6218], [114359, 380.26044], [212731, 363.0318], [203246, 338.78738]]  |
# |18             |[[39581, 168.26779], [71773, 159.50677], [199790, 134.10098], [96677, 126.23855], [114359, 119.28293]] |
# |38             |[[71773, 352.01993], [96677, 204.685], [134956, 188.80072], [147821, 163.27094], [199790, 159.45114]]  |
# |67             |[[71773, 99.51257], [96677, 71.12844], [199790, 65.6105], [147821, 57.351524], [218813, 54.869522]]    |
# |70             |[[71773, 222.00186], [39581, 162.15457], [96677, 116.9384], [229047, 110.507324], [199790, 110.38161]] |
# |93             |[[106149, 252.10336], [157276, 218.13629], [161753, 178.49902], [191848, 161.1553], [96677, 153.29684]]|
# |161            |[[199790, 182.36797], [39581, 138.93335], [92132, 128.23593], [181198, 116.14143], [96677, 112.39105]] |
# |186            |[[147821, 99.32215], [71773, 84.59311], [212731, 81.023895], [96677, 77.098724], [229047, 72.590904]]  |
# |190            |[[161753, 140.81335], [106422, 140.63466], [147821, 124.55389], [96677, 117.54036], [72301, 115.96803]]|
# |218            |[[39581, 229.30612], [71773, 216.15286], [105901, 128.61086], [106422, 123.84717], [114359, 117.87496]]|
# +---------------+-------------------------------------------------------------------------------------------------------+


recommended_songs = (
    topK
    .withColumn("recommended_songs", extract_songs_top_k_udf(F.col("recommendations")))
    .select("user_id_encoded", "recommended_songs")
)
recommended_songs.cache()
recommended_songs.count()

935642

recommended_songs.show(10, False)

# +---------------+---------------------------------------+
# |user_id_encoded|recommended_songs                      |
# +---------------+---------------------------------------+
# |12             |[71773, 134956, 114359, 212731, 203246]|
# |18             |[39581, 71773, 199790, 96677, 114359]  |
# |38             |[71773, 96677, 134956, 147821, 199790] |
# |67             |[71773, 96677, 199790, 147821, 218813] |
# |70             |[71773, 39581, 96677, 229047, 199790]  |
# |93             |[106149, 157276, 161753, 191848, 96677]|
# |161            |[199790, 39581, 92132, 181198, 96677]  |
# |186            |[147821, 71773, 212731, 96677, 229047] |
# |190            |[161753, 106422, 147821, 96677, 72301] |
# |218            |[39581, 71773, 105901, 106422, 114359] |
# +---------------+---------------------------------------+



# Relevant songs

relevant_songs = (
    testData
    .select(
        F.col("user_id_encoded").cast(IntegerType()),
        F.col("song_id_encoded").cast(IntegerType()),
        F.col("plays").cast(IntegerType())
    )
    .groupBy('user_id_encoded')
    .agg(
        collect_list(
            array(
                F.col("song_id_encoded"),
                F.col("plays")
            )
        ).alias('relevance')
    )
    .withColumn("relevant_songs", extract_songs_udf(F.col("relevance")))
    .select("user_id_encoded", "relevant_songs")
)
relevant_songs.cache()
relevant_songs.count()

# 933115

relevant_songs.show(10, False)

# |12             |[63137, 9151, 19307, 1783, 25170, 38472, 693, 9929, 191191, 22114, 59222, 24325, 27460, 84703, 64095, 26384, 30807, 58511, 30146, 16513, 7423, 115154, 54220, 206980, 77933, 20928, 85805, 37980, 27742, 12896, 87948, 206053, 153385, 42690, 164680, 154176, 128520, 78150, 193368, 3813, 1269, 82155, 12479, 70420, 23535, 429, 9040, 1813, 2976, 116865, 43022, 3547, 21042, 22527, 12577, 97402, 11904, 8420, 10047, 42438, 10052, 22905, 86024, 58611, 6132, 120380, 3434, 11691, 73583, 85784, 23993, 24905, 28885, 19407, 4017, 10145, 5035, 6843, 73402, 696, 62123, 11143, 81670, 712, 91817, 142208, 8545, 12785, 10788, 2979, 1833, 46036, 120655, 3765, 119603, 87577, 83155, 122056, 107845, 1001, 38776, 20119, 77718, 80035, 87046, 12901, 46127, 16343, 96651, 1545, 84606, 8801, 61540, 54553, 1737, 37480, 3219, 17919, 136120, 25282, 15165, 38373, 47004, 76220, 58050, 48897, 790, 110434, 11061, 5431, 24393, 98898, 10254, 6337, 2851, 5698, 8434, 14130, 6771, 19979, 118741, 7848, 45569, 153294, 194494, 41428, 27264, 37186, 25816, 73192, 22615, 214922, 1321, 37672, 11218, 11214, 1997, 170608, 14856, 2937, 14254, 5382, 116216, 121069, 6601, 135316, 23074, 72547, 13094, 34236, 121587, 41254, 6363, 10637, 1465, 15139, 22621, 37737, 24572, 16658, 24108, 26044, 25835, 2579, 3811, 230661, 41668, 22986, 937, 150561, 45073, 7224, 24930, 9049, 25406, 169881, 32668, 18668, 34524, 15812, 36354, 34143, 14006, 203, 6631, 22581, 10459, 9192, 5364, 738, 16610, 33654, 51821, 147, 1880, 28410, 10270, 13646, 24907, 12598, 5566, 11605, 104305, 1712, 12327, 18627, 842, 8597, 16100, 10672, 16294, 56664, 24103, 22947, 6719, 29823, 35510, 23455, 4806, 43017, 14773, 8156, 57504, 20643, 79576, 1454, 30994, 4514, 37599, 21769, 11103, 5312, 1179, 20740, 14396, 8279, 212, 16272, 51223, 1918, 5426, 23595, 3242, 4378, 17966, 2452, 40097, 2246, 17669, 29714, 23734, 40075, 43260, 562, 13686, 3464, 26297, 1537, 1642, 27025, 33264, 25652, 14778, 31794, 37873, 7493, 18113, 12365, 16476, 59220, 15056, 25661, 3232, 222744, 15800, 14993, 11886, 9158, 13570, 22649, 12350, 7274, 22981, 7131, 451, 10050, 26867, 33233, 334, 55659, 13757, 42636, 821, 8783, 27325, 1985, 20067, 15073, 406, 27778, 41473, 9188, 35936, 2905, 29903, 26663, 94516, 6123, 35192, 25084, 22278, 8386, 17981, 39392, 307, 58588, 18985, 37520, 13938, 19931, 14772, 5544, 24866, 22960, 54415, 5573, 11911, 12192, 10613, 44383, 15339, 5902, 115518, 24850, 72456, 25049, 10441, 4203, 6857, 108719, 9147, 1698, 33574, 14923, 21580, 12392, 836, 5814, 18914, 10629, 11155, 38910, 19651, 3377, 31105, 1569, 19206, 15595, 1152, 116933, 433, 37106, 4621, 4077, 25929, 4870, 28684, 3089, 24028, 16314, 36606, 31503, 3672, 7332, 18468, 31522, 44354, 23468, 79076, 14558, 35036, 30942, 23832, 33561, 45682, 8270, 32299, 1647, 17045, 106680, 62867, 4226, 23444]|


combined = (
    recommended_songs.join(relevant_songs, on='user_id_encoded', how='inner')
    .rdd
    .map(lambda row: (row[1], row[2]))
)
combined.cache()
combined.count()

# 933115

combined.take(1)


rankingMetrics = RankingMetrics(combined)
ndcgAtK = rankingMetrics.ndcgAt(k)
print(ndcgAtK)

#1.6891639452388736e-05   # when taking the threshold as 30 for both user_counts and song_counts we get value of 0.039 but we are losing so many songs and users which might not be good for business.

precisionAt = rankingMetrics.precisionAt(k)
print(precisionAt)

#1.4945481020306704e-05

map = rankingMetrics.meanAveragePrecision
print(map)

#3.5745867123281877e-06

# Checking if recommended song is actually been heard by the user

# triplets_limited.where((F.col("user_id_encoded") ==  12356) & (F.col("song_id_encoded") ==  35596)).show()
# recommended_songs.where(F.col("user_id_encoded") ==  12356).show()